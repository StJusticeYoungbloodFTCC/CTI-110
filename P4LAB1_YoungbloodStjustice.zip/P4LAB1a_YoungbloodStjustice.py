# St. Justice Youngblood
# 7/3/25
# P4LAB1a
# Desc: This program will draw a triangle and a square. 

import turtle

square = turtle.Turtle()
square.color("blue")

triangle = turtle.Turtle()
triangle.color("green")

turnCounterSquare = 0
turnCounterTriangle = 0

while turnCounterSquare < 4:
    square.forward(100)
    square.left(90)
    while turnCounterTriangle < 3:
        triangle.forward(80)
        triangle.left(120)
        turnCounterTriangle += 1
    turnCounterSquare += 1
                    
turtle.exitonclick()
