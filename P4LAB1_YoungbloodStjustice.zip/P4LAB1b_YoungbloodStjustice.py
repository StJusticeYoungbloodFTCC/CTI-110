# St. Justice Youngblood
# 7/3/25
# P4LAB1b
# Desc: This program will draw out my initials.

import turtle

turtle.left(180)

# S initial 
turtle.forward(100)
turtle.left(90)
turtle.forward(100)
turtle.left(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)

# Y initial
turtle.penup()
turtle.right(180)
turtle.forward(225)
turtle.left(90)
turtle.pendown()
turtle.forward(125)
turtle.left(45)
turtle.forward(100)
turtle.left(180)
turtle.forward(100)
turtle.left(90)
turtle.forward(100)

